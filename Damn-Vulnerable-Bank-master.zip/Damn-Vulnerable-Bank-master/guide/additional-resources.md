# Additional Resources

* [OWASP Mobile Security Testing Guide](https://owasp.org/www-project-mobile-security-testing-guide/)

